import prasad from "./test1.js"
import { mul,SuperHuman,Human } from "./test1.js"
let obj2 = new SuperHuman(22, 44, 66)
obj2.print()
console.log(Human.a)

console.log(typeof Human)

const res = prasad(5, 6)
const res2 = mul(5, 6)
console.log(res, res2)
