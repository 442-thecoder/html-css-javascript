const para = document.querySelectorAll('.para')
console.log(para)
// console.log(para.textContent)
// console.log(para.innerText)
// para.textContent="msdbhm"

// para[0]].textContent = "Hello World"
// console.log(para[0].textContent)

// para[0].innerText = "Bye World"
// console.log(para[0].innerText)
// para[0].innerHTML= `<strong>My World</strong>`
/**   take paragraph from  html and change the text using textContent ,innerText and innerHTML */