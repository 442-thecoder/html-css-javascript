// // // /* multi line comment */
// // // //single line comment



// // // // alert("application successfully completely")
// // // let num1 = prompt("enter a value") //show one box and it will ask value, 5 =>'5'
// // // console.log(typeof(num1))
// // // let num2 = prompt("enter a value")
// // // //6=>'6'

// // // console.log(num1+num2)//'5'+'6'
// // // console.log("my first javascript")


// // /* variables*/

// // /*var, let and const */
// // /* var till 2015(ES6), let and const */
// // /* var:*/
// // // console.log(a) //Hoisting
// // // var a = 20;
// // // var a = 50;
// // // let b = 20;
// // // b = 50;
// // // console.log(b)

// // // const c = 20;

// // // console.log(c)





// // // var a = 55;
// // // console.log(a)

// // // function add ()
// // // {
// // //     if (true)
// // //     {
// // //       var pt =50;
// // //     }
// // //     console.log(pt)
// // // }
// // // add()
// // // debugger;
// // // console.log(p1)

// // // var p1 = 55;
// // // let a = 63;
// // // const c = 65;
// // // console.log(a, c)
// // // function fun ()
// // // {
// // //     console.log(b)
// // //     var b = 55;
// // //     console.log(b)
// // // }
// // // fun()
// // /* numbers */

// // let a = 55;

// // console.log(typeof(a))















// /** how to put comments in JS
// 1. multiline   /*  vhjbxvmxbnmvxm
// <xcbvxmbvxbvm></xcbvxmbvxbvm>*/
// /* 2.single line
// //cbxhjbxmbvmxbvm
// //nxvcnhbxnvxn//






// //This is my first javascript code
// /*This is my first javascript code*/

// let p=10;
// var q=20;
// const r=30;
// /* redeclare for let not possible*/
// p=15;
// var q=30;
// q=35;
// /* redeclare and re assign not possible in const*/
// console.log(p, q, r)// 15 35 30


// console.log(typeof(p))

// let a = 2.3666
// console.log(a.toFixed(3)) //2.367
// console.log(a.toPrecision(3)) //2.37
// console.log(a.toString(8))

/* program to find quadratic roots */

// const a = 1, b = -2, c = 1;
// let x1= (-b+Math.sqrt(b*b-4*a*c))/(2*a)
// let x2 = (-b - Math.sqrt(b * b - 4 * a * c)) / (2 * a)

// console.log("x1=" + x1, " x2=" + x2)
// let str1 = "the time is 12' 0 clock"
// let str2= 'the kalam said "do it"'
// console.log(str1)
// console.log(str2)



//string concatenation
//string interpolation
// let a= Number(prompt("Enter a value"))
// let  b = 30;
// console.log(`the sum of ${a} and ${b} is ${a + b}`)





//take 2 values from the prompt and add,sub,mult,div them and print
// let a = Number(prompt("enter a value"))
// let b = Number(prompt("enter a value"))
// console.log(`the addition of ${a} and ${b} is ${a + b}`)
// console.log(`the subtraction of ${a} and ${b} is ${a - b}`)
// console.log(`the mul of ${a} and ${b} is ${a * b}`)
// console.log(`the div of ${a} and ${b} is ${a / b}`)
// let str = "javascript is so fun and easy"
// console.log("total number of charaters are " + str.length)

// let str = prompt()
// let str1 = str.split('').reverse().join('')
// if (str == str1) console.log("success")
// else console.log("fail")

/* Boolean */
/*true,false*/
/* undefined and null*/
/* null is defined abscence of value*/
/**undefined is an accidental abscence of value */
/* not defined is not a data type,it's a error*/
let k=null;
console.log(k)


